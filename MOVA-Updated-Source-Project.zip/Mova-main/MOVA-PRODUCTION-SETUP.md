# MOVA project update and production setup

## Changes in this update
- Replaced the old Moniepoint placeholder on the Premium upgrade screen with the supplied MOVA Kuda account:
  - Account name: MOVA DIGITAL HUB
  - Account number: 3004611364
  - Bank: KUDA MICROFINANCE BANK
- Premium transfer submission no longer activates Premium automatically. It records a pending reference in the current browser only. Do not treat this local preview record as a payment confirmation.
- Removed the fake account-name generator. Withdrawal account lookup now calls `/api/resolve-account` on the server and returns the bank provider's confirmed name.
- Added a welcome popup and a 3-step getting-started guide: profile, bank details, Premium.
- Removed the email-contains-admin shortcut and the visible role-switch control. The admin page is restricted to accounts with an admin role in the application state.
- Added a dark theme toggle with neutral surface/text adjustments that preserve MOVA blue and orange accents.
- Kept the reflex and lucky-wheel mini-games playable. Wheel outcomes are now game badges/entries, not pretend cash credits.

## Required environment variable for account-name lookup
The account lookup endpoint uses Paystack's bank resolve API. Add this on Vercel:
- `PAYSTACK_SECRET_KEY` = your Paystack **secret** key

Keep this key server-side only. Never add it to a `VITE_` variable or frontend source. Use a Paystack test secret key for testing, then switch to the live key only after business verification and approval. Bank support depends on the bank code list in `api/resolve-account.js`.

If the key is missing, the endpoint deliberately returns a clear setup error. It will not invent account names.

## What is not live yet
This ZIP is not a fully connected production backend. The existing app still has browser-local demo authentication/state. Client-side task, quiz, click, talking-stage and referral cash-credit actions have been disabled until a secure server ledger is connected. The Premium transfer reference is saved to localStorage and is not shared with a separate admin device. No admin can safely verify a payment across devices until Supabase (or another database) and server-side authorization are connected.

The SQL foundation is in `supabase/schema.sql`. Create a Supabase project, run that SQL, and then connect the app's registration/login, member profiles, bank details, payment submissions, wallet ledger, task completion and admin review to Supabase server-side APIs. Do not launch real cash rewards until every credit is written to the server ledger with eligibility checks, daily limits, idempotency and admin review where required.

## Admin access
Do not create an admin by typing "admin" in an email address. The demo shortcut has been removed. In production, the platform owner must be authenticated through Supabase and assigned `app_metadata.role = "admin"` from a trusted server-side process. The admin dashboard must check that trusted role on every server request, not only hide a menu item in React.

## Payment confirmation
For bank transfers, verify the actual credit in the MOVA receiving account or through an approved bank/payment provider integration. Only then should the server mark `premium_payments.status = 'confirmed'`, update the member's `membership_status`, and write an audit record. Never activate based on a screenshot, browser redirect, or user-submitted reference alone.

## Build and deployment
- Framework: Vite + React + TypeScript
- Build command: `npm run build`
- Output directory: `dist`
- Install command: `npm install`

Dependency installation was attempted in this environment but did not complete within the available execution window, so a successful production build has not been confirmed.
