export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const secret = process.env.PAYSTACK_SECRET_KEY;
  if (!secret) return res.status(503).json({ error: 'Bank verification is not configured. The platform administrator must add PAYSTACK_SECRET_KEY in the hosting environment.' });
  const { accountNumber, bankName } = req.body || {};
  if (!/^\d{10}$/.test(String(accountNumber || ''))) return res.status(400).json({ error: 'Enter a valid 10-digit account number.' });
  const bankCodes = {
    'Access Bank': '044',
    'Guaranty Trust Bank (GTBank)': '058',
    'Zenith Bank': '057',
    'United Bank for Africa (UBA)': '033',
    'First Bank of Nigeria': '011',
    'OPay Digital Services': '999992',
    'PalmPay': '999991',
    'Moniepoint Microfinance Bank': '50515',
    'Kuda Microfinance Bank': '50211',
    'Stanbic IBTC Bank': '221',
    'Fidelity Bank': '070',
    'FCMB (First City Monument Bank)': '214',
    'Union Bank of Nigeria': '032',
    'Sterling Bank': '232',
    'Wema Bank (ALAT)': '035',
    'Ecobank Nigeria': '050',
    'Polaris Bank': '076',
    'Jaiz Bank': '301',
    'Providus Bank': '101',
    'Taj Bank': '302',
    'Rubies Bank': '125',
    'VFD Microfinance Bank': '566'
  };
  const bankCode = bankCodes[bankName];
  if (!bankCode) return res.status(400).json({ error: 'This bank is not yet supported for account lookup.' });
  try {
    const url = new URL('https://api.paystack.co/bank/resolve');
    url.searchParams.set('account_number', accountNumber);
    url.searchParams.set('bank_code', bankCode);
    const upstream = await fetch(url, { headers: { Authorization: `Bearer ${secret}` } });
    const payload = await upstream.json();
    if (!upstream.ok || !payload.status || !payload.data?.account_name) {
      return res.status(422).json({ error: payload.message || 'The bank could not confirm this account. Check the details and try again.' });
    }
    return res.status(200).json({ accountName: payload.data.account_name, accountNumber, bankName });
  } catch {
    return res.status(502).json({ error: 'Bank verification provider could not be reached. Please try again.' });
  }
}
